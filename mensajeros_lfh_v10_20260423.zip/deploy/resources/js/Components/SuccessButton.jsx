import React from 'react';

export default function SuccessButton({ className = '', disabled, children, ...props }) {
    return (
        <button
            {...props}
            className={
                `inline-flex items-center px-6 py-3 bg-emerald-600 dark:bg-emerald-500 border border-transparent rounded-xl font-black text-[10px] text-white uppercase tracking-widest hover:bg-emerald-700 dark:hover:bg-emerald-400 focus:bg-emerald-700 active:bg-emerald-800 focus:outline-none focus:ring-4 focus:ring-emerald-500/20 transition-all duration-200 shadow-lg shadow-emerald-500/30 dark:shadow-emerald-500/10 active:scale-95 disabled:opacity-25 ${disabled && 'opacity-25'
                } ` + className
            }
            disabled={disabled}
        >
            {children}
        </button>
    );
}
